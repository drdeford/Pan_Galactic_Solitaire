

colors=['#8c0000', 'yellow', 'green', '#00cca3', '#0088cc', '#0000ff', '#cc00ff', '#cc0052', '#ff2200', '#006652', '#002233', '#0000cc', '#5c0073', '#330007', '#b24700', '#403300', '#073300', '#00becc', '#0066ff', '#0000bf', '#cc00a3', '#663600', '#cad900', '#00993d', '#005c73', '#003380', '#0e0033', '#73003d']
color_list=colors+colors+colors
import Tkinter as tk
from random import *
#import tkinter.simpledialog
import time
from newpgsol import *
root = tk.Tk()


root.title("Pan-Galactic Solitaire")
root.iconify()
frame1 = tk.Toplevel()
frame1.title("Pan-Galactic Solitaire")
frame1.iconify()
toplevel=tk.Toplevel()
ck4=tk.PhotoImage(file="ck4.gif")
bl=tk.Label(toplevel,image=ck4)
bl.grid(row=0,column=0)
bl2=tk.Label(toplevel,image=ck4)
bl2.grid(row=0,column=3)
bt=tk.Label(toplevel,text="Welcome to Pan-Galactic Solitaire",fg="purple",font=("helvetica",24))
bt.grid(row=0,column=2)
bb=tk.Button(toplevel,text="Play Game",fg="green",bg="purple",font=("helvetica",14),command=lambda:stuff(toplevel,frame1))#toplevel.iconify)
bb.grid(row=2,column=2)
bb2=tk.Button(toplevel,text="Options", command=lambda:options(),fg="yellow")
bb2.grid(row=3,column=2)
bb2=tk.Button(toplevel,text="Help", command=lambda:help(),fg="blue")
bb2.grid(row=4,column=2)
bb3=tk.Button(toplevel,text="Quit", command=root.destroy,fg="red")
bb3.grid(row=5,column=2)

def stuff(a,b):
	a.iconify()
	b.deiconify()
def options():
	top=tk.Toplevel()
	top.title("Options")
	t3=tk.Label(top,text="Currently there are no options to set...\nJust play the game!!! ",font=("helvetica",16),fg="blue")
	t3.grid(row=0,column=0)
	bb5=tk.Button(top,text="Moving On...",fg="red",command=top.destroy)
	bb5.grid(row=2,column=0)

def help():
	top1=tk.Toplevel()
	top1.title("HELP!!!!")
	t3=tk.Label(top1,text="RULES OF THE GAME",fg="blue",font=("helvetica",24))
	t3.grid(row=0,column=0)
	t3=tk.Label(top1,text="Welcome to Pan-Galactic Solitaire, based on Professor Doyle's algorithm for infinite division without choice. The rules of the game are quite simple:\n All 52 cards are dealt face-up in a 4x13 arrray. Each row is identified with a particular suit; from bottom to top the ordering is spades, hearts, diamonds, clubs (standard bridge ordering).\n Only one type of move is permitted:\n When a card lies in the row corresponding to its suit and there is another card of the same suit in its column,\n the second card may be exchanged for the card of the same rank as the first card that corresponds to the row of the second card (think about it for a minute).\n The game ends when no more moves are possible. A game is considered won if each column contains cards of a single rank.\n GOOD LUCK!!!   ",fg="blue",font=("helvetica",14))
	t3.grid(row=1,column=0)
	bb5=tk.Button(top1,text="Moving On...",fg="red",command=top1.destroy)
	bb5.grid(row=2,column=0)

sdeck=['As', 'Ah', 'Ad', 'Ac',  '2s', '2h', '2d', '2c', '3s', '3h', '3d', '3c', '4s', '4h', '4d', '4c', '5s', '5h', '5d', '5c', '6s', '6h', '6d', '6c', '7s', '7h', '7d', '7c', '8s', '8h', '8d', '8c', '9s', '9h', '9d', '9c', '1s', '1h', '1d', '1c', 'Js', 'Jh', 'Jd', 'Jc', 'Qs', 'Qh', 'Qd', 'Qc', 'Ks', 'Kh', 'Kd', 'Kc']
photolist=[]
capdict={'s':'S','h':'H','c':'C','d':'D'}
d={'h':'\u2665','s':'\u2660','d':'\u2666','c':'\u2663'}
capdict={'s':'S','h':'H','c':'C','d':'D'}
isd={'\u2665':'h','\u2660':'s','\u2666':'d','\u2663':'c'}
swaps=0
shuffle(sdeck)
def restart(sdeck,frame1):
	shuffle(sdeck)
	click2(sdeck,frame1,0,0)
	
def undo(deck,frame1,swaps):
	top=tk.Toplevel()
	t3=tk.Label(top,text="You must make another legitimate move\nbefore undoing again",fg="yellow",font=("helvetica",16))
	t3.grid(row=0,column=0)
	bb5=tk.Button(top,text="Moving On...",fg="red",command=top.destroy)
	bb5.grid(row=1,column=0)
	click2(deck,frame1,-1,swaps-1)
	
def undo1(deck):
	top=tk.Toplevel()
	t3=tk.Label(top,text="You haven't even done anything yet...",fg="orange",font=("helvetica",16))
	t3.grid(row=0,column=0)
	bb5=tk.Button(top,text="Moving On...",fg="red",command=top.destroy)
	bb5.grid(row=1,column=0)

#button_flag = True

def click2(sdeck,f,p,swaps):
	#1+1
	#print(sdeck)
	osdeck=sdeck[:]
	f.destroy()
	frame1 = tk.Toplevel()
	frame1.title("Pan-Galactic Solitaire")
	bb3=tk.Button(frame1,text="Quit", command=root.destroy,fg="red")
	bb3.grid(row=5,column=12)
	bb2=tk.Button(frame1,text="Options", command=lambda:options(),fg="yellow")
	bb2.grid(row=5,column=11)
	bb2=tk.Button(frame1,text="Help", command=lambda:help(),fg="blue")
	bb2.grid(row=5,column=10)
	
	#col=[[],[],[],[]]
	#for j in range(4):
	#	for i in range(13):
    #		col[j].append(sdeck[13*j+i])
	row=[]
	for i in range(13):
		row.append([])
	for i in range(13):
		for j in range(4):
			row[i].append(sdeck[i+13*j])
	#print(row)
	moveset=[]
	inds=[]
	sdict={0:'c',1:'d',2:'h',3:'s'}
	rdict={'c':0,'d':1,'h':2,'s':3}
	for i in range(52):
		if rdict[sdeck[i][1]]*13-1<i<(rdict[sdeck[i][1]]+1)*13:
			for j in range(3):
				if sdeck[(i+13*(j+1))%52][1]==sdeck[i][1]:
					moveset.append(sdeck[(i+13*(j+1))%52])
					inds.append((i+13*(j+1))%52)
	
	
	if p==0:
		p=moveset[0]
	swap=p
	if swap in moveset:
		swaps=swaps+1
		sw=str(swaps)
		l2=tk.Label(frame1,text="Moves: "+sw,fg="blue")
		l2.grid(row=5,column=0)
		sdeck=updater(swap,sdeck,row)
		

	else:
		if p==-1:
			p=-1
		else:
			ouchframe=tk.Toplevel()
			t1=tk.Label(ouchframe,text="That is not a permissible move!\n (no cheating allowed)",font=("helvetica",16),fg="red")
			t1.grid(row=0,column=1)
			bt1=tk.Button(ouchframe,text="OK",fg="red",command=ouchframe.destroy)
			bt1.grid(row=1,column=1)
	
	
	
	
	#placedict={}
	#for i in range(4):
	#	for j in range(13):
	#		if row[j][i][1]==d[sdict[i]]:
	#			for k in range(3):
	#				if row[j][(i+k+1)%4][1]==row[j][i][1]:
	#					moveset.append(row[j][(i+k+1)%4])
	#clist=[]
	#ddd=sdeck[:]
	#for i in range(len(moveset)):
#		temp=tupdater(moveset[i],ddd,row)
#		clist.append([moveset[i],inds[i],temp])
#	print(clist)       




	moveset=[]
	inds=[]
	sdict={0:'c',1:'d',2:'h',3:'s'}
	rdict={'c':0,'d':1,'h':2,'s':3}
	for i in range(52):
		if rdict[sdeck[i][1]]*13-1<i<(rdict[sdeck[i][1]]+1)*13:
			for j in range(3):
				if sdeck[(i+13*(j+1))%52][1]==sdeck[i][1]:
					moveset.append([sdeck[(i+13*(j+1))%52],(i+13*(j+1))%52])
					inds.append((i+13*(j+1))%52)
					
	tlist=[]
	ddd=sdeck[:]
	for i in range(len(moveset)):
		target=tupdater(moveset[i][0],ddd,row)
		tlist.append([moveset[i],target])
	#print(tlist)				
	color_list=[]
	for i in range(52):
		color_list.append('white')	
	for i in range(len(tlist)):
		color_list[tlist[i][0][1]]=colors[i%28]
		color_list[tlist[i][1][1]]=colors[i%28]
					      
	if moveset==[]:
		l1=tk.Label(frame1,text="NO LEGAL MOVES",fg="red")
		l1.grid(row=5,column=3)
		check=0
		for i in range(13):
			if row[i][0][0]==row[i][1][0] and row[i][0][0]==row[i][2][0] and row[i][0][0]==row[i][3][0]:
				check=check+1
		if check == 13:
			ouchframe=tk.Toplevel()
			t1=tk.Label(ouchframe,text="YOU WON!!!\n CONGRATULATIONS\n:)",font=("helvetica",16))
		
			t1.grid(row=0,column=1)
			bt1=tk.Button(ouchframe,text="THANKS FOR PLAYING",fg="red",command=ouchframe.destroy)
			bt1.grid(row=1,column=1)
                                
		else:
			ouchframe=tk.Toplevel()
			t1=tk.Label(ouchframe,text="OOPS!!\nYOU LOST\n:(",font=("helvetica",16))
		
			t1.grid(row=0,column=1)
			bt1=tk.Button(ouchframe,text="THANKS FOR PLAYING",fg="red",command=ouchframe.destroy)
			bt1.grid(row=1,column=1)

	#print(swap)
	#print(sdeck)
	#if swap in moveset:
		#sdeck=updater(swap,sdeck,row)
	#sdeck=updater(swap,sdeck,row)
	#shuffle(sdeck)
	#print(sdeck)
	#frame1.destroy
	#print(moveset)
	und=tk.Button(frame1,fg="purple",text="UNDO",command=lambda:undo(osdeck,frame1,swaps))
	und.grid(row=5,column=9)
	#frame2.pack(side=tk.TOP, fill=tk.X)
	photolist=[]
	for i in range(52):
		photolist.append([])
	newtop=tk.Toplevel()
	for i in range(52):
		#photolist.append(tk.PhotoImage(file=capdict[sdeck[i][1]]+sdeck[i][0]+".gif"))
		label.append([])
		photo=tk.PhotoImage(file=capdict[sdeck[i][1]]+sdeck[i][0]+".gif")
		#photolist.append(tk.PhotoImage(file=capdict[sdeck[i][1]]+sdeck[i][0]+".gif"))
		photolist[i]=photo
		label[i] = tk.Label(newtop,image=photo)
		label[i].image = photo # keep a reference!
		label[i].pack()
	
	cardback=tk.PhotoImage(file="Deck3.gif")
	label[52]=tk.Label(newtop,image=cardback)
	label[52].image = cardback # keep a reference!
	label[52].pack()
	for i in range(13):
		if sdeck[i][0]==sdeck[i+13][0]==sdeck[i+26][0]==sdeck[i+39][0]:
			photolist[i]=cardback
			photolist[i+13]=cardback
			photolist[i+26]=cardback
			photolist[i+39]=cardback
	
	#print(photolist)
	startover=tk.Button(frame1,compound=tk.TOP,text="Redeal",command=lambda:restart(sdeck,frame1),bg='purple',fg="green")#, image=photolist[9]) #image=photolist[5],command=frame1.destroy)
	startover.grid(row=5,column=8)
	#print(sdeck)
	buttons=[]
	for i in range(52):
		buttons.append([])
	buttons[ 0 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 0 ],bg=color_list[0],command=lambda:click2(sdeck,frame1,sdeck[0],swaps) )#swap(i,sdeck)))
	buttons[ 1 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 1 ],bg=color_list[1],command=lambda:click2(sdeck,frame1,sdeck[1],swaps) )#swap(i,sdeck)))
	buttons[ 2 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 2 ],bg=color_list[2],command=lambda:click2(sdeck,frame1,sdeck[2],swaps) )#swap(i,sdeck)))
	buttons[ 3 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 3 ],bg=color_list[3],command=lambda:click2(sdeck,frame1,sdeck[3],swaps) )#swap(i,sdeck)))
	buttons[ 4 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 4 ],bg=color_list[4],command=lambda:click2(sdeck,frame1,sdeck[4],swaps) )#swap(i,sdeck)))
	buttons[ 5 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 5 ],bg=color_list[5],command=lambda:click2(sdeck,frame1,sdeck[5],swaps) )#swap(i,sdeck)))
	buttons[ 6 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 6 ],bg=color_list[6],command=lambda:click2(sdeck,frame1,sdeck[6],swaps) )#swap(i,sdeck)))
	buttons[ 7 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 7 ],bg=color_list[7],command=lambda:click2(sdeck,frame1,sdeck[7],swaps) )#swap(i,sdeck)))
	buttons[ 8 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 8 ],bg=color_list[8],command=lambda:click2(sdeck,frame1,sdeck[8],swaps) )#swap(i,sdeck)))
	buttons[ 9 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 9 ],bg=color_list[9],command=lambda:click2(sdeck,frame1,sdeck[9],swaps) )#swap(i,sdeck)))
	buttons[ 10 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 10 ],bg=color_list[10],command=lambda:click2(sdeck,frame1,sdeck[10],swaps) )#swap(i,sdeck)))
	buttons[ 11 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 11 ],bg=color_list[11],command=lambda:click2(sdeck,frame1,sdeck[11],swaps) )#swap(i,sdeck)))
	buttons[ 12 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 12 ],bg=color_list[12],command=lambda:click2(sdeck,frame1,sdeck[12],swaps) )#swap(i,sdeck)))
	buttons[ 13 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 13 ],bg=color_list[13],command=lambda:click2(sdeck,frame1,sdeck[13],swaps) )#swap(i,sdeck)))
	buttons[ 14 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 14 ],bg=color_list[14],command=lambda:click2(sdeck,frame1,sdeck[14],swaps) )#swap(i,sdeck)))
	buttons[ 15 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 15 ],bg=color_list[15],command=lambda:click2(sdeck,frame1,sdeck[15],swaps) )#swap(i,sdeck)))
	buttons[ 16 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 16 ],bg=color_list[16],command=lambda:click2(sdeck,frame1,sdeck[16],swaps) )#swap(i,sdeck)))
	buttons[ 17 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 17 ],bg=color_list[17],command=lambda:click2(sdeck,frame1,sdeck[17],swaps) )#swap(i,sdeck)))
	buttons[ 18 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 18 ],bg=color_list[18],command=lambda:click2(sdeck,frame1,sdeck[18],swaps) )#swap(i,sdeck)))
	buttons[ 19 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 19 ],bg=color_list[19],command=lambda:click2(sdeck,frame1,sdeck[19],swaps) )#swap(i,sdeck)))
	buttons[ 20 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 20 ],bg=color_list[20],command=lambda:click2(sdeck,frame1,sdeck[20],swaps) )#swap(i,sdeck)))
	buttons[ 21 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 21 ],bg=color_list[21],command=lambda:click2(sdeck,frame1,sdeck[21],swaps) )#swap(i,sdeck)))
	buttons[ 22 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 22 ],bg=color_list[22],command=lambda:click2(sdeck,frame1,sdeck[22],swaps) )#swap(i,sdeck)))
	buttons[ 23 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 23 ],bg=color_list[23],command=lambda:click2(sdeck,frame1,sdeck[23],swaps) )#swap(i,sdeck)))
	buttons[ 24 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 24 ],bg=color_list[24],command=lambda:click2(sdeck,frame1,sdeck[24],swaps) )#swap(i,sdeck)))
	buttons[ 25 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 25 ],bg=color_list[25],command=lambda:click2(sdeck,frame1,sdeck[25],swaps) )#swap(i,sdeck)))
	buttons[ 26 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 26 ],bg=color_list[26],command=lambda:click2(sdeck,frame1,sdeck[26],swaps) )#swap(i,sdeck)))
	buttons[ 27 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 27 ],bg=color_list[27],command=lambda:click2(sdeck,frame1,sdeck[27],swaps) )#swap(i,sdeck)))
	buttons[ 28 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 28 ],bg=color_list[28],command=lambda:click2(sdeck,frame1,sdeck[28],swaps) )#swap(i,sdeck)))
	buttons[ 29 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 29 ],bg=color_list[29],command=lambda:click2(sdeck,frame1,sdeck[29],swaps) )#swap(i,sdeck)))
	buttons[ 30 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 30 ],bg=color_list[30],command=lambda:click2(sdeck,frame1,sdeck[30],swaps) )#swap(i,sdeck)))
	buttons[ 31 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 31 ],bg=color_list[31],command=lambda:click2(sdeck,frame1,sdeck[31],swaps) )#swap(i,sdeck)))
	buttons[ 32 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 32 ],bg=color_list[32],command=lambda:click2(sdeck,frame1,sdeck[32],swaps) )#swap(i,sdeck)))
	buttons[ 33 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 33 ],bg=color_list[33],command=lambda:click2(sdeck,frame1,sdeck[33],swaps) )#swap(i,sdeck)))
	buttons[ 34 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 34 ],bg=color_list[34],command=lambda:click2(sdeck,frame1,sdeck[34],swaps) )#swap(i,sdeck)))
	buttons[ 35 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 35 ],bg=color_list[35],command=lambda:click2(sdeck,frame1,sdeck[35],swaps) )#swap(i,sdeck)))
	buttons[ 36 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 36 ],bg=color_list[36],command=lambda:click2(sdeck,frame1,sdeck[36],swaps) )#swap(i,sdeck)))
	buttons[ 37 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 37 ],bg=color_list[37],command=lambda:click2(sdeck,frame1,sdeck[37],swaps) )#swap(i,sdeck)))
	buttons[ 38 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 38 ],bg=color_list[38],command=lambda:click2(sdeck,frame1,sdeck[38],swaps) )#swap(i,sdeck)))
	buttons[ 39 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 39 ],bg=color_list[39],command=lambda:click2(sdeck,frame1,sdeck[39],swaps) )#swap(i,sdeck)))
	buttons[ 40 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 40 ],bg=color_list[40],command=lambda:click2(sdeck,frame1,sdeck[40],swaps) )#swap(i,sdeck)))
	buttons[ 41 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 41 ],bg=color_list[41],command=lambda:click2(sdeck,frame1,sdeck[41],swaps) )#swap(i,sdeck)))
	buttons[ 42 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 42 ],bg=color_list[42],command=lambda:click2(sdeck,frame1,sdeck[42],swaps) )#swap(i,sdeck)))
	buttons[ 43 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 43 ],bg=color_list[43],command=lambda:click2(sdeck,frame1,sdeck[43],swaps) )#swap(i,sdeck)))
	buttons[ 44 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 44 ],bg=color_list[44],command=lambda:click2(sdeck,frame1,sdeck[44],swaps) )#swap(i,sdeck)))
	buttons[ 45 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 45 ],bg=color_list[45],command=lambda:click2(sdeck,frame1,sdeck[45],swaps) )#swap(i,sdeck)))
	buttons[ 46 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 46 ],bg=color_list[46],command=lambda:click2(sdeck,frame1,sdeck[46],swaps) )#swap(i,sdeck)))
	buttons[ 47 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 47 ],bg=color_list[47],command=lambda:click2(sdeck,frame1,sdeck[47],swaps) )#swap(i,sdeck)))
	buttons[ 48 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 48 ],bg=color_list[48],command=lambda:click2(sdeck,frame1,sdeck[48],swaps) )#swap(i,sdeck)))
	buttons[ 49 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 49 ],bg=color_list[49],command=lambda:click2(sdeck,frame1,sdeck[49],swaps) )#swap(i,sdeck)))
	buttons[ 50 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 50 ],bg=color_list[50],command=lambda:click2(sdeck,frame1,sdeck[50],swaps) )#swap(i,sdeck)))
	buttons[ 51 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 51 ],bg=color_list[51],command=lambda:click2(sdeck,frame1,sdeck[51],swaps) )#swap(i,sdeck)))buttons[ 0 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 0 ],bg='green',command=lambda:click2(sdeck,frame1,sdeck[0]) )#swap(i,sdeck)))

	
	#for i in range(52):
	#	buttons[i]=tk.Button(frame1,compound=tk.TOP,width=110,height=110, bg='green', command = lambda : click2(sdeck,frame1,sdeck[i]),image=photolist[i] )#, command=click(sdeck)))#swap(i,sdeck)))	
	for j in range(13):
		for k in range(4):
			buttons[j+13*k].grid(row=k,column=j)	
	newtop.destroy()
	#frame1.destroy
	#return 


#    """
#    respond to the button click
#    """
#    global button_flag
#    # toggle button colors as a test
#    if button_flag:
#        button1.config(bg="white")
#        button_flag = False
#    else:
#        button1.config(bg="'green'")
#        button_flag = True

#def swap(i,sdeck):
	
	
#w=tkinter.simpledialog.Dialog
	
	

# create a frame and pack it
#frame1 = tk.Toplevel(root)
#frame1.title("Pan-Galactic Solitaire")
#frame1.pack(side=tk.TOP, fill=tk.X)

bb3=tk.Button(frame1,text="Quit", command=root.destroy,fg="red")
bb3.grid(row=5,column=12)
bb2=tk.Button(frame1,text="Options", command=lambda:options(),fg="yellow")
bb2.grid(row=5,column=11)
bb2=tk.Button(frame1,text="Help", command=lambda:help(),fg="blue")
bb2.grid(row=5,column=10)
photolist=[]
label=[]
for i in range(52):
	photolist.append([])
newtop1=tk.Toplevel()
for i in range(52):
	label.append([])
	photo=tk.PhotoImage(file=capdict[sdeck[i][1]]+sdeck[i][0]+".gif")
	#photolist.append(tk.PhotoImage(file=capdict[sdeck[i][1]]+sdeck[i][0]+".gif"))
	photolist[i]=photo
	label[i] = tk.Label(newtop1,image=photo)
	label[i].image = photo # keep a reference!
	label[i].pack()
	

# create the image button, image is above (top) the optional text
#button1 = tk.Button(frame1, compound=tk.TOP, width=155, height=155, image=photo1,
   #text="optional text", bg=''green'', command=click)
#button1.pack(side=tk.LEFT, padx=2, pady=2)
#button1.grid(row=0,column=2)
row=[]
moveset=[]
inds=[]
sdict={0:'c',1:'d',2:'h',3:'s'}
rdict={'c':0,'d':1,'h':2,'s':3}
for i in range(52):
	if rdict[sdeck[i][1]]*13-1<i<(rdict[sdeck[i][1]]+1)*13:
		for j in range(3):
			if sdeck[(i+13*(j+1))%52][1]==sdeck[i][1]:
				moveset.append([sdeck[(i+13*(j+1))%52],(i+13*(j+1))%52])
				inds.append((i+13*(j+1))%52)

color_list=[]
tlist=[]
ddd=sdeck[:]
for i in range(len(moveset)):
	target=tupdater(moveset[i][0],ddd,row)
	tlist.append([moveset[i],target])
	#print(tlist)				
color_list=[]
for i in range(52):
	color_list.append('white')	
for i in range(len(tlist)):
	color_list[tlist[i][0][1]]=colors[i%28]
	color_list[tlist[i][1][1]]=colors[i%28]
# pick a (small) image file you have in the working directory ...
#photo1 = tk.PhotoImage(file="C2.gif")
#button2 = tk.Button(frame1, compound=tk.TOP, width=155, height=155, image=photo1,
    #text="optional text", bg=''green'', command=click)
#button1.pack(side=tk.LEFT, padx=2, pady=2)
#button2.grid(row=1,column=3)
# save the button's image from garbage collection (needed?)
#button1.image = photo1
startover=tk.Button(frame1,compound=tk.TOP,text="Redeal",fg="green", bg='purple',command=lambda:restart(sdeck,frame1))
startover.grid(row=5,column=8)

buttons=[]
und=tk.Button(frame1,fg="purple",text="UNDO",command=lambda:undo1(sdeck))
und.grid(row=5,column=9)
#button=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[i],
#bg=''green'',command=click(sdeck))
#button.grid(row=0,column=4)	
for i in range(52):
	buttons.append([])
buttons[ 0 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 0 ],bg=color_list[0],command=lambda:click2(sdeck,frame1,sdeck[0],swaps) )#swap(i,sdeck)))
buttons[ 1 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 1 ],bg=color_list[1],command=lambda:click2(sdeck,frame1,sdeck[1],swaps) )#swap(i,sdeck)))
buttons[ 2 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 2 ],bg=color_list[2],command=lambda:click2(sdeck,frame1,sdeck[2],swaps) )#swap(i,sdeck)))
buttons[ 3 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 3 ],bg=color_list[3],command=lambda:click2(sdeck,frame1,sdeck[3],swaps) )#swap(i,sdeck)))
buttons[ 4 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 4 ],bg=color_list[4],command=lambda:click2(sdeck,frame1,sdeck[4],swaps) )#swap(i,sdeck)))
buttons[ 5 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 5 ],bg=color_list[5],command=lambda:click2(sdeck,frame1,sdeck[5],swaps) )#swap(i,sdeck)))
buttons[ 6 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 6 ],bg=color_list[6],command=lambda:click2(sdeck,frame1,sdeck[6],swaps) )#swap(i,sdeck)))
buttons[ 7 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 7 ],bg=color_list[7],command=lambda:click2(sdeck,frame1,sdeck[7],swaps) )#swap(i,sdeck)))
buttons[ 8 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 8 ],bg=color_list[8],command=lambda:click2(sdeck,frame1,sdeck[8],swaps) )#swap(i,sdeck)))
buttons[ 9 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 9 ],bg=color_list[9],command=lambda:click2(sdeck,frame1,sdeck[9],swaps) )#swap(i,sdeck)))
buttons[ 10 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 10 ],bg=color_list[10],command=lambda:click2(sdeck,frame1,sdeck[10],swaps) )#swap(i,sdeck)))
buttons[ 11 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 11 ],bg=color_list[11],command=lambda:click2(sdeck,frame1,sdeck[11],swaps) )#swap(i,sdeck)))
buttons[ 12 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 12 ],bg=color_list[12],command=lambda:click2(sdeck,frame1,sdeck[12],swaps) )#swap(i,sdeck)))
buttons[ 13 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 13 ],bg=color_list[13],command=lambda:click2(sdeck,frame1,sdeck[13],swaps) )#swap(i,sdeck)))
buttons[ 14 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 14 ],bg=color_list[14],command=lambda:click2(sdeck,frame1,sdeck[14],swaps) )#swap(i,sdeck)))
buttons[ 15 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 15 ],bg=color_list[15],command=lambda:click2(sdeck,frame1,sdeck[15],swaps) )#swap(i,sdeck)))
buttons[ 16 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 16 ],bg=color_list[16],command=lambda:click2(sdeck,frame1,sdeck[16],swaps) )#swap(i,sdeck)))
buttons[ 17 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 17 ],bg=color_list[17],command=lambda:click2(sdeck,frame1,sdeck[17],swaps) )#swap(i,sdeck)))
buttons[ 18 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 18 ],bg=color_list[18],command=lambda:click2(sdeck,frame1,sdeck[18],swaps) )#swap(i,sdeck)))
buttons[ 19 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 19 ],bg=color_list[19],command=lambda:click2(sdeck,frame1,sdeck[19],swaps) )#swap(i,sdeck)))
buttons[ 20 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 20 ],bg=color_list[20],command=lambda:click2(sdeck,frame1,sdeck[20],swaps) )#swap(i,sdeck)))
buttons[ 21 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 21 ],bg=color_list[21],command=lambda:click2(sdeck,frame1,sdeck[21],swaps) )#swap(i,sdeck)))
buttons[ 22 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 22 ],bg=color_list[22],command=lambda:click2(sdeck,frame1,sdeck[22],swaps) )#swap(i,sdeck)))
buttons[ 23 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 23 ],bg=color_list[23],command=lambda:click2(sdeck,frame1,sdeck[23],swaps) )#swap(i,sdeck)))
buttons[ 24 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 24 ],bg=color_list[24],command=lambda:click2(sdeck,frame1,sdeck[24],swaps) )#swap(i,sdeck)))
buttons[ 25 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 25 ],bg=color_list[25],command=lambda:click2(sdeck,frame1,sdeck[25],swaps) )#swap(i,sdeck)))
buttons[ 26 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 26 ],bg=color_list[26],command=lambda:click2(sdeck,frame1,sdeck[26],swaps) )#swap(i,sdeck)))
buttons[ 27 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 27 ],bg=color_list[27],command=lambda:click2(sdeck,frame1,sdeck[27],swaps) )#swap(i,sdeck)))
buttons[ 28 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 28 ],bg=color_list[28],command=lambda:click2(sdeck,frame1,sdeck[28],swaps) )#swap(i,sdeck)))
buttons[ 29 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 29 ],bg=color_list[29],command=lambda:click2(sdeck,frame1,sdeck[29],swaps) )#swap(i,sdeck)))
buttons[ 30 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 30 ],bg=color_list[30],command=lambda:click2(sdeck,frame1,sdeck[30],swaps) )#swap(i,sdeck)))
buttons[ 31 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 31 ],bg=color_list[31],command=lambda:click2(sdeck,frame1,sdeck[31],swaps) )#swap(i,sdeck)))
buttons[ 32 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 32 ],bg=color_list[32],command=lambda:click2(sdeck,frame1,sdeck[32],swaps) )#swap(i,sdeck)))
buttons[ 33 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 33 ],bg=color_list[33],command=lambda:click2(sdeck,frame1,sdeck[33],swaps) )#swap(i,sdeck)))
buttons[ 34 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 34 ],bg=color_list[34],command=lambda:click2(sdeck,frame1,sdeck[34],swaps) )#swap(i,sdeck)))
buttons[ 35 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 35 ],bg=color_list[35],command=lambda:click2(sdeck,frame1,sdeck[35],swaps) )#swap(i,sdeck)))
buttons[ 36 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 36 ],bg=color_list[36],command=lambda:click2(sdeck,frame1,sdeck[36],swaps) )#swap(i,sdeck)))
buttons[ 37 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 37 ],bg=color_list[37],command=lambda:click2(sdeck,frame1,sdeck[37],swaps) )#swap(i,sdeck)))
buttons[ 38 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 38 ],bg=color_list[38],command=lambda:click2(sdeck,frame1,sdeck[38],swaps) )#swap(i,sdeck)))
buttons[ 39 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 39 ],bg=color_list[39],command=lambda:click2(sdeck,frame1,sdeck[39],swaps) )#swap(i,sdeck)))
buttons[ 40 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 40 ],bg=color_list[40],command=lambda:click2(sdeck,frame1,sdeck[40],swaps) )#swap(i,sdeck)))
buttons[ 41 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 41 ],bg=color_list[41],command=lambda:click2(sdeck,frame1,sdeck[41],swaps) )#swap(i,sdeck)))
buttons[ 42 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 42 ],bg=color_list[42],command=lambda:click2(sdeck,frame1,sdeck[42],swaps) )#swap(i,sdeck)))
buttons[ 43 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 43 ],bg=color_list[43],command=lambda:click2(sdeck,frame1,sdeck[43],swaps) )#swap(i,sdeck)))
buttons[ 44 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 44 ],bg=color_list[44],command=lambda:click2(sdeck,frame1,sdeck[44],swaps) )#swap(i,sdeck)))
buttons[ 45 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 45 ],bg=color_list[45],command=lambda:click2(sdeck,frame1,sdeck[45],swaps) )#swap(i,sdeck)))
buttons[ 46 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 46 ],bg=color_list[46],command=lambda:click2(sdeck,frame1,sdeck[46],swaps) )#swap(i,sdeck)))
buttons[ 47 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 47 ],bg=color_list[47],command=lambda:click2(sdeck,frame1,sdeck[47],swaps) )#swap(i,sdeck)))
buttons[ 48 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 48 ],bg=color_list[48],command=lambda:click2(sdeck,frame1,sdeck[48],swaps) )#swap(i,sdeck)))
buttons[ 49 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 49 ],bg=color_list[49],command=lambda:click2(sdeck,frame1,sdeck[49],swaps) )#swap(i,sdeck)))
buttons[ 50 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 50 ],bg=color_list[50],command=lambda:click2(sdeck,frame1,sdeck[50],swaps) )#swap(i,sdeck)))
buttons[ 51 ]=tk.Button(frame1,compound=tk.TOP,width=80,height=105, image=photolist[ 51 ],bg=color_list[51],command=lambda:click2(sdeck,frame1,sdeck[51],swaps) )
for j in range(13):
	for k in range(4):
		buttons[j+13*k].grid(row=k,column=j)	
l2=tk.Label(frame1,text="Moves: 0",fg="blue")
l2.grid(row=5,column=0)
#b00=tk.Button(frame1,compound=tk.TOP, width=80,height=105, image=photolist[0],bg=''green'',command=click)
#b00.grid(row=0,column=0)

# start the event loop
newtop1.destroy()



root.mainloop()
	
	
