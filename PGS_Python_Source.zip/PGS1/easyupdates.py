#from numpy import *
#from scipy import *
from random import *
def playgame(ranks):
        cards=52
        suits=['s','h','d','c']
        deck=[]
        sdeck=['As', 'Ah', 'Ad', 'Ac',  '2s', '2h', '2d', '2c', '3s', '3h', '3d', '3c', '4s', '4h', '4d', '4c', '5s', '5h', '5d', '5c', '6s', '6h', '6d', '6c', '7s', '7h', '7d', '7c', '8s', '8h', '8d', '8c', '9s', '9h', '9d', '9c', '1s', '1h', '1d', '1c', 'Js', 'Jh', 'Jd', 'Jc', 'Qs', 'Qh', 'Qd', 'Qc', 'Ks', 'Kh', 'Kd', 'Kc']
        d={'h':'\u2665','s':'\u2660','d':'\u2666','c':'\u2663'}
        for i in range(52):
            sdeck[i]=sdeck[i][0]+d[sdeck[i][1]]
	#for i in range(13):
        #    for j in suits:
        #        deck.append(str(i)+j)
        #print(len(sdeck))
        shuffle(sdeck)
        #deal=list(ideal)
        complete=0
        while complete==0:
                disp(sdeck)

                col=[[],[],[],[]]
                for j in range(4):
                        for i in range(13):
                                col[j].append(sdeck[13*j+i])
                row=[]
                for i in range(13):
                        row.append([])
                for i in range(13):
                        for j in range(4):
                               row[i].append(sdeck[i+13*j])

                moveset=[]
                sdict={0:'c',1:'d',2:'h',3:'s'}
                placedict={}
                for i in range(4):
                        for j in range(13):
                                if row[j][i][1]==d[sdict[i]]:
                                        for k in range(3):
                                                if row[j][(i+k+1)%4][1]==row[j][i][1]:
                                                        moveset.append(row[j][(i+k+1)%4])
                                    
                            
                if moveset==[]:
                        print('NO MOVES LEFT!!!\n')
                        check=0
                        for i in range(13):
                                if row[i][0][0]==row[i][1][0] and row[i][0][0]==row[i][2][0] and row[i][0][0]==row[i][3][0]:
                                        check=check+1
                        if check == 13:
                                print('YOU WIN!!!!')
                                ans=1
                        else:
                                print('YOU LOSE!!!')
                                ans=0
                        complete=complete+1
                        disp(sdeck)
                else:
                        print(moveset)
                        swap=input('\nWhich card do you want to switch?\n')
                        testswap=swap[0]+d[swap[1]]
                        if testswap in moveset:
                                sdeck=updater(swap,sdeck,row)
                        
                
        
def disp(deal):
        col=[[],[],[],[]]
        
        sdeck=['As', 'Ah', 'Ad', 'Ac',  '2s', '2h', '2d', '2c', '3s', '3h', '3d', '3c', '4s', '4h', '4d', '4c', '5s', '5h', '5d', '5c', '6s', '6h', '6d', '6c', '7s', '7h', '7d', '7c', '8s', '8h', '8d', '8c', '9s', '9h', '9d', '9c', '10s', '10h', '10d', '10c', 'Js', 'Jh', 'Jd', 'Jc', 'Qs', 'Qh', 'Qd', 'Qc', 'Ks', 'Kh', 'Kd', 'Kc']
        
        ddeck=[]
        #for i in range(52):
        #    for i in range(4):
                
        for j in range(4):
                for i in range(13):
                        col[j].append(deal[13*j+i])
        row=[]
        for i in range(13):
                row.append([])
        for i in range(13):
                for j in range(4):
                        row[i].append(deal[i+13*j])

        line1=''
        line2=''
        line3=''
        line4=''
        line0=''
        line5=''
        
        for i in range(66):
            line0=line0+'#'
        for i in range(66):
            line5=line5+'#'
        for i in range(13):
                line1=line1+col[0][i]+'   '
        for i in range(13):
                line2=line2+col[1][i]+'   '
        for i in range(13):
                line3=line3+col[2][i]+'   '
        for i in range(13):
                line4=line4+col[3][i]+'   '
        
        print('\n\n\n  '+line0,'\n'+' \u2663 '+line1+'\u2663','\n','\u2666 '+line2+'\u2666','\n','\u2665 '+line3+'\u2665','\n','\u2660 '+line4+'\u2660','\n',' '+line5)
        return
                
	
	
def updater(swap,sdeck,row):
##        outr=0
##        outc=0
##        inr=0
##        inc=0
##        
##        for i in range(13):
##                for j in range(4):
##                        if r[i][j]==swap:
##                                outr=j
##                                outc=i
##        for i in range(13):
##                for j in range(4):
##                        if r[i][j][0]=r[swap[0]][0] and r[i][j][1]==swap[1]:
##                            inr=j
##                            inc=i
        sdict={0:'c',1:'d',2:'h',3:'s'}
        isdict={'c':0,'d':1,'h':2,'s':3}
        d={'h':'\u2665','s':'\u2660','d':'\u2666','c':'\u2663'}
        isd={'\u2665':'h','\u2660':'s','\u2666':'d','\u2663':'c'}
        indo=0
        outr=0
        outc=0
        indi=0
        target=''
        newswap=swap[0]+swap[1]
        print(newswap)
        #print(newswap)
        for i in range(52):
                if newswap==sdeck[i]:
                        indo=i
        #print(indo)
        #for i in range(13):
        #        for j in range(4):
        #               if newswap==row[i][j]:
        #                       outr=j
        #                       outc=i
        #                       print(outr,outc)
        rtest=0
        if sdeck[(indo+13)%52][0]==sdeck[(indo+26)%52][0]==sdeck[(indo+39)%52][0]:
                rtest=1
        else:
                rtest=2
        #print(indo,rtest)
        if 13*isdict[swap[1]]-1<indo<13*(isdict[swap[1]]+1) and rtest==1:
        	#pick the 4th card
                inrank=sdeck[(indo+13)%52][0]
                insuit=swap[1]
                target=inrank+insuit
                print(newswap,target)
                for i in range(52):
                        if target==sdeck[i]:
                                indi=i
                sdeck[indo],sdeck[indi]=sdeck[indi],sdeck[indo]
                return sdeck
    
        else:
      
    
            outsuit=newswap[1]
       # print(outsuit)
            if -1<indo<13:
                    insuit='c'
                    inrow=0
            if 12<indo<26:
    	            insuit='d'
    	            inrow=1
            if 25<indo<39:
                    insuit='h'
                    inrow=2
            if 38<indo<52:
            	    insuit='s'
            	    inrow=3
        #print(insuit)
            rdict={'c':0,'d':1,'h':2,'s':3}
            inrank=sdeck[13*rdict[newswap[1]]+(indo %13)][0]
        #print(13*rdict[newswap[1]]+(indo %13))
        #print(sdeck[13*rdict[newswap[1]]+(indo %13)])
            target=target+inrank+insuit
        #print(target)
            for i in range(52):
                    if target==sdeck[i]:
                            indi=i
            sdeck[indo],sdeck[indi]=sdeck[indi],sdeck[indo]
        
                
        return(sdeck)
        
def tupdater(swap,sdeck,row):
##        outr=0
##        outc=0
##        inr=0
##        inc=0
##        
##        for i in range(13):
##                for j in range(4):
##                        if r[i][j]==swap:
##                                outr=j
##                                outc=i
##        for i in range(13):
##                for j in range(4):
##                        if r[i][j][0]=r[swap[0]][0] and r[i][j][1]==swap[1]:
##                            inr=j
##                            inc=i
        sdict={0:'c',1:'d',2:'h',3:'s'}
        isdict={'c':0,'d':1,'h':2,'s':3}
        d={'h':'\u2665','s':'\u2660','d':'\u2666','c':'\u2663'}
        isd={'\u2665':'h','\u2660':'s','\u2666':'d','\u2663':'c'}
        indo=0
        outr=0
        outc=0
        indi=0
        target=''
        newswap=swap[0]+swap[1]
        #print(newswap)
        for i in range(52):
                if newswap==sdeck[i]:
                        indo=i
        #print(indo)
        #for i in range(13):
        #        for j in range(4):
        #               if newswap==row[i][j]:
        #                       outr=j
        #                       outc=i
        #                       print(outr,outc)
        rtest=0
        if sdeck[(indo+13)%52][0]==sdeck[(indo+26)%52][0]==sdeck[(indo+39)%52][0]:
                rtest=1
        else:
                rtest=2
        #print(indo,rtest)
        if 13*isdict[swap[1]]-1<indo<13*(isdict[swap[1]]+1) and rtest==1:
        	#pick the 4th card
                inrank=sdeck[(indo+13)%52][0]
                insuit=swap[1]
                target=inrank+insuit
                #print(newswap,target)
                for i in range(52):
                        if target==sdeck[i]:
                                indi=i
                sdeck[indo],sdeck[indi]=sdeck[indi],sdeck[indo]
                return [target,indi]
        else:
                outsuit=newswap[1]
       # print(outsuit)
                if -1<indo<13:
        	        insuit='c'
        	        inrow=0
                if 12<indo<26:
        	        insuit='d'
        	        inrow=1
                if 25<indo<39:
        	        insuit='h'
        	        inrow=2
                if 38<indo<52:
        	        insuit='s'
        	        inrow=3
        #print(insuit)
                rdict={'c':0,'d':1,'h':2,'s':3}
                inrank=sdeck[13*rdict[newswap[1]]+(indo %13)][0]
        #print(13*rdict[newswap[1]]+(indo %13))
        #print(sdeck[13*rdict[newswap[1]]+(indo %13)])
                target=target+inrank+insuit
        #print(target)
                #print(newswap,target)
                for i in range(52):
                        if target==sdeck[i]:
                                indi=i
                sdeck[indo],sdeck[indi]=sdeck[indi],sdeck[indo]
        
                
                return [target, indi]
